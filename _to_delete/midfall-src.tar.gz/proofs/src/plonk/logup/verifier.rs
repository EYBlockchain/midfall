// This file is part of MIDNIGHT-ZK.
// Copyright (C) 2025 Midnight Foundation
// SPDX-License-Identifier: Apache-2.0
// Licensed under the Apache License, Version 2.0 (the "License");
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Verifier implementation for the LogUp lookup argument.

use std::iter;

use ff::{PrimeField, WithSmallOrderMulGroup};

use crate::{
    plonk::{
        logup::{self, ChunkedArgument},
        Error, VerifyingKey,
    },
    poly::{commitment::PolynomialCommitmentScheme, CommitmentLabel, Rotation, VerifierQuery},
    transcript::{Hashable, Transcript},
};

/// Commitment to the shared multiplicity polynomial, read from the transcript.
pub struct CommittedMultiplicities<F: PrimeField, CS: PolynomialCommitmentScheme<F>> {
    multiplicities: CS::Commitment,
}

/// Commitments to all LogUp polynomials for a [`ChunkedArgument`].
///
/// One shared `m` and `Z`, plus one `hᵢ` per chunk.
#[derive(Debug)]
pub struct Committed<F: PrimeField, CS: PolynomialCommitmentScheme<F>> {
    multiplicities: CS::Commitment,
    /// One commitment per chunk of the batched argument.
    helper_polys: Vec<CS::Commitment>,
    accumulator: CS::Commitment,
}

/// Commitments plus evaluations at the challenge point.
pub struct Evaluated<F: PrimeField, CS: PolynomialCommitmentScheme<F>> {
    committed: Committed<F, CS>,
    pub(crate) evaluated: logup::Evaluated<F>,
}

impl<F: WithSmallOrderMulGroup<3>> ChunkedArgument<F> {
    /// Reads the multiplicities commitment from the transcript.
    pub(in crate::plonk) fn read_multiplicities<T: Transcript, CS: PolynomialCommitmentScheme<F>>(
        &self,
        transcript: &mut T,
    ) -> Result<CommittedMultiplicities<F, CS>, Error>
    where
        CS::Commitment: Hashable<T::Hash>,
        <T::Hash as crate::transcript::TranscriptHash>::Input:
            crate::transcript::TranscriptInputBytes,
    {
        let multiplicities = transcript.read()?;
        #[cfg(feature = "solidity-verifier-trace")]
        crate::plonk::solidity_trace::record_proof_commitment::<T::Hash, _>(
            "proof_lookup_multiplicity_commitment",
            &multiplicities,
        );
        Ok(CommittedMultiplicities { multiplicities })
    }
}

impl<F: WithSmallOrderMulGroup<3>, CS: PolynomialCommitmentScheme<F>>
    CommittedMultiplicities<F, CS>
{
    /// Reads `nb_chunks` helper commitments and one accumulator commitment
    /// from the transcript.
    pub(in crate::plonk) fn read_commitment<T: Transcript>(
        self,
        nb_chunks: usize,
        transcript: &mut T,
    ) -> Result<Committed<F, CS>, Error>
    where
        CS::Commitment: Hashable<T::Hash>,
        <T::Hash as crate::transcript::TranscriptHash>::Input:
            crate::transcript::TranscriptInputBytes,
    {
        let helper_polys =
            (0..nb_chunks).map(|_| transcript.read()).collect::<Result<Vec<_>, _>>()?;
        #[cfg(feature = "solidity-verifier-trace")]
        {
            for commitment in &helper_polys {
                crate::plonk::solidity_trace::record_proof_commitment::<T::Hash, _>(
                    "proof_lookup_helper_commitment",
                    commitment,
                );
            }
        }
        let accumulator = transcript.read()?;
        #[cfg(feature = "solidity-verifier-trace")]
        crate::plonk::solidity_trace::record_proof_commitment::<T::Hash, _>(
            "proof_lookup_accumulator_commitment",
            &accumulator,
        );

        Ok(Committed {
            multiplicities: self.multiplicities,
            helper_polys,
            accumulator,
        })
    }
}

impl<F: PrimeField, CS: PolynomialCommitmentScheme<F>> Committed<F, CS> {
    /// Reads the polynomial evaluations from the transcript.
    ///
    /// Order: `m_eval`, then `hᵢ_eval` for each batched chunk, then `Z_eval`,
    /// `Z(ωx)_eval`.
    pub(crate) fn evaluate<T: Transcript>(
        self,
        transcript: &mut T,
    ) -> Result<Evaluated<F, CS>, Error>
    where
        F: Hashable<T::Hash>,
        <T::Hash as crate::transcript::TranscriptHash>::Input:
            crate::transcript::TranscriptInputBytes,
    {
        let nb_chunks = self.helper_polys.len();

        let multiplicities_eval = transcript.read()?;
        #[cfg(feature = "solidity-verifier-trace")]
        crate::plonk::solidity_trace::record_proof_eval::<T::Hash, _>(
            "proof_lookup_multiplicity_eval",
            &multiplicities_eval,
        );
        let helper_evals =
            (0..nb_chunks).map(|_| transcript.read()).collect::<Result<Vec<_>, _>>()?;
        #[cfg(feature = "solidity-verifier-trace")]
        {
            for eval in &helper_evals {
                crate::plonk::solidity_trace::record_proof_eval::<T::Hash, _>(
                    "proof_lookup_helper_eval",
                    eval,
                );
            }
        }
        let accumulator_eval = transcript.read()?;
        #[cfg(feature = "solidity-verifier-trace")]
        crate::plonk::solidity_trace::record_proof_eval::<T::Hash, _>(
            "proof_lookup_accumulator_eval",
            &accumulator_eval,
        );
        let accumulator_next_eval = transcript.read()?;
        #[cfg(feature = "solidity-verifier-trace")]
        crate::plonk::solidity_trace::record_proof_eval::<T::Hash, _>(
            "proof_lookup_accumulator_next_eval",
            &accumulator_next_eval,
        );

        Ok(Evaluated {
            committed: self,
            evaluated: logup::Evaluated {
                multiplicities_eval,
                helper_evals,
                accumulator_eval,
                accumulator_next_eval,
            },
        })
    }
}

impl<F: WithSmallOrderMulGroup<3>, CS: PolynomialCommitmentScheme<F>> Evaluated<F, CS> {
    /// Returns verification queries for all committed polynomials.
    pub(in crate::plonk) fn queries(
        &self,
        vk: &VerifyingKey<F, CS>,
        x: F,
    ) -> impl Iterator<Item = VerifierQuery<'_, F, CS>> + Clone {
        let x_next = vk.domain.rotate_omega(x, Rotation::next());

        let m_query = iter::once(VerifierQuery::new(
            x,
            CommitmentLabel::NoLabel,
            &self.committed.multiplicities,
            self.evaluated.multiplicities_eval,
        ));

        let helper_queries = self
            .committed
            .helper_polys
            .iter()
            .zip(self.evaluated.helper_evals.iter())
            .map(move |(com, &eval)| VerifierQuery::new(x, CommitmentLabel::NoLabel, com, eval))
            .collect::<Vec<_>>();

        let z_queries = [
            VerifierQuery::new(
                x,
                CommitmentLabel::NoLabel,
                &self.committed.accumulator,
                self.evaluated.accumulator_eval,
            ),
            VerifierQuery::new(
                x_next,
                CommitmentLabel::NoLabel,
                &self.committed.accumulator,
                self.evaluated.accumulator_next_eval,
            ),
        ];

        m_query.chain(helper_queries).chain(z_queries)
    }
}

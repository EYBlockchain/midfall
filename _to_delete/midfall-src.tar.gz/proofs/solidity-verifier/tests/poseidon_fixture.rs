//! Step 8 end-to-end smoke test for the midnight-proofs Solidity
//! verifier on BLS12-381 / EIP-2537.
//!
//! The test rebuilds the same circuit the midfall poseidon fixture
//! (`midfall/proofs/solidity-verifier/fixtures/poseidon/`) was generated
//! from - `ZkStdLib`-backed `PoseidonExample` at `k = 6` - generates a
//! fresh proof against the local Filecoin SRS, renders the
//! `Halo2Verifier.sol` + `Halo2VerifyingKey.sol` pair through
//! `SolidityGenerator::render` with separate VK output, compiles them with
//! `solc`, deploys both to a Prague-spec revm (so EIP-2537 BLS12-381
//! precompiles `0x0b` / `0x0c` / `0x0f` are routed to revm's bundled
//! implementations), encodes calldata via the generator
//! and finally calls `verifyProof`. Pass condition is `output ==
//! 0x...01` (the verifier accepted the proof) AND a successful native
//! `midnight_zk_stdlib::verify` against the same proof.
//!
//! Gated behind `feature = "evm,truncated-challenges"`. Skipped automatically
//! when the host lacks the local SRS / `solc` binary; otherwise it asserts both
//! the Yul renders cleanly and the Prague-spec EVM accepts the proof.
//!
//! NOTE: this test depends on `midnight-zk-stdlib` + `midnight-circuits`
//! from the immutable Midfall revision configured in `Cargo.toml`. The
//! `[patch]` blocks redirect every `midnight-*` reference to that same
//! Git source so cargo resolves a single canonical crate copy across
//! the whole dep graph.

#![cfg(all(feature = "evm", feature = "truncated-challenges"))]

use std::{env, path::Path};

use ff::Field;
use halo2_solidity_verifier::{
    compile_solidity, pinned_solc_available, Evm, GeneratorConfig, QuotientIdentitySource,
    RenderOptions, RenderVk, SolidityGenerator,
};
use midnight_circuits::{
    hash::poseidon::PoseidonChip,
    instructions::{hash::HashCPU, AssignmentInstructions, PublicInputInstructions},
};
use midnight_curves::Fq;
use midnight_proofs::{
    circuit::{Layouter, Value},
    plonk::Error,
};
use midnight_zk_stdlib::{utils::plonk_api::srs_for_test, Relation, ZkStdLib, ZkStdLibArch};
use rand::SeedableRng;
use rand_chacha::ChaCha8Rng;
use sha3::Keccak256;

type F = Fq;
const RUN_EVM_TESTS_ENV: &str = "HALO2_SOLIDITY_RUN_EVM_TESTS";

#[derive(Clone, Default)]
struct PoseidonExample;

impl Relation for PoseidonExample {
    type Instance = F;

    type Witness = [F; 3];

    fn format_instance(instance: &Self::Instance) -> Result<Vec<F>, Error> {
        Ok(vec![*instance])
    }

    fn circuit(
        &self,
        std_lib: &ZkStdLib,
        layouter: &mut impl Layouter<F>,
        _instance: Value<Self::Instance>,
        witness: Value<Self::Witness>,
    ) -> Result<(), Error> {
        let assigned_message = std_lib.assign_many(layouter, &witness.transpose_array())?;
        let output = std_lib.poseidon(layouter, &assigned_message)?;
        std_lib.constrain_as_public_input(layouter, &output)
    }

    fn used_chips(&self) -> ZkStdLibArch {
        ZkStdLibArch {
            poseidon: true,
            ..ZkStdLibArch::default()
        }
    }

    fn write_relation<W: std::io::Write>(&self, _writer: &mut W) -> std::io::Result<()> {
        Ok(())
    }

    fn read_relation<R: std::io::Read>(_reader: &mut R) -> std::io::Result<Self> {
        Ok(PoseidonExample)
    }
}

fn srs_dir() -> String {
    env::var("SRS_DIR").unwrap_or_else(|_| {
        concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../zk_stdlib/examples/assets"
        )
        .to_string()
    })
}

/// Step 8 end-to-end smoke. It depends on the Filecoin SRS asset, solc, and
/// Prague EIP-2537 precompile support, so default CI skips it unless
/// `HALO2_SOLIDITY_RUN_EVM_TESTS=1` is set. Run explicitly via:
///   HALO2_SOLIDITY_RUN_EVM_TESTS=1 cargo test --features
/// evm,truncated-challenges --test poseidon_fixture -- --nocapture
/// Enable Solidity trace logs with:
///   HALO2_SOLIDITY_RUN_EVM_TESTS=1 cargo test --features
/// evm,truncated-challenges,solidity-trace --test poseidon_fixture --
/// --nocapture
#[test]
fn poseidon_renders_compiles_and_verifies() {
    const K: u32 = 6;

    if !env_flag_enabled(RUN_EVM_TESTS_ENV) {
        eprintln!("skipping poseidon end-to-end smoke: set {RUN_EVM_TESTS_ENV}=1 to run it");
        return;
    }

    // The Filecoin SRS file is loaded by `srs_for_test` via the
    // `SRS_DIR` env var. Skip the test cleanly if the asset is
    // unavailable on the host (e.g. fresh checkout where the SRS
    // hasn't been downloaded yet).
    let srs_dir = srs_dir();
    let srs_path = format!("{srs_dir}/bls_filecoin_2p{K}");
    let fallback_srs_path = format!("{srs_dir}/bls_filecoin_2p19");
    // The gate was explicitly requested, so a missing asset fails rather than
    // silently reporting a pass that rendered and compiled nothing.
    assert!(
        Path::new(&srs_path).exists() || Path::new(&fallback_srs_path).exists(),
        "{RUN_EVM_TESTS_ENV}=1 requires the test SRS, but it was not found at {srs_path} or \
         {fallback_srs_path}.
Fetch it with:
    curl -L -o {fallback_srs_path} \
         https://midnight-s3-fileshare-dev-eu-west-1.s3.eu-west-1.amazonaws.com/bls_filecoin_2p19
or point SRS_DIR at an existing copy."
    );
    env::set_var("SRS_DIR", &srs_dir);

    let relation = PoseidonExample;
    let srs = srs_for_test(&relation, Some(K));
    let vk = midnight_zk_stdlib::setup_vk(&srs, &relation);
    let pk = midnight_zk_stdlib::setup_pk(&relation, &vk);

    let mut rng = ChaCha8Rng::seed_from_u64(42);
    let witness: [F; 3] = core::array::from_fn(|_| F::random(&mut rng));
    let instance = <PoseidonChip<F> as HashCPU<F, F>>::hash(&witness);

    let prover_rng = ChaCha8Rng::seed_from_u64(0xdebd);
    let proof = midnight_zk_stdlib::prove::<PoseidonExample, Keccak256>(
        &srs, &pk, &relation, &instance, witness, prover_rng,
    )
    .expect("Proof generation should not fail");

    // Sanity-check via the native verifier first. If this fails, the
    // proof itself is broken so any Solidity-side mismatch downstream
    // is meaningless.
    midnight_zk_stdlib::verify::<PoseidonExample, Keccak256>(
        &srs.verifier_params(),
        &vk,
        &instance,
        None,
        &proof,
    )
    .expect("native verify should accept the proof");

    // Render Halo2Verifier.sol + Halo2VerifyingKey.sol against the
    // same VK. ZkStdLib creates two instance columns (one committed,
    // one non-committed); set num_committed_instances accordingly.
    let num_instances = 1;
    let generator = SolidityGenerator::new(&srs, vk.vk(), GeneratorConfig::new(num_instances, 1));
    assert_poseidon_quotient_manifest(&generator);
    let trace_solidity = halo2_solidity_verifier::SOLIDITY_TRACE_ENABLED;
    let gas_checkpoints_enabled = halo2_solidity_verifier::SOLIDITY_GAS_CHECKPOINTS_ENABLED;
    let artifacts = generator
        .render(RenderOptions {
            vk: RenderVk::Separate,
            ..RenderOptions::default()
        })
        .expect("separate render should succeed");
    let verifier_solidity = artifacts.verifier;
    let vk_solidity = artifacts.verifying_key.expect("separate render includes VK");

    // Persist for post-mortem inspection.
    let dump_dir = format!(
        "{}/target/poseidon-fixture-dump",
        env!("CARGO_MANIFEST_DIR")
    );
    std::fs::create_dir_all(&dump_dir).ok();
    std::fs::write(format!("{dump_dir}/Halo2Verifier.sol"), &verifier_solidity).ok();
    std::fs::write(format!("{dump_dir}/Halo2VerifyingKey.sol"), &vk_solidity).ok();
    std::fs::write(format!("{dump_dir}/proof.bin"), &proof).ok();
    std::fs::write(
        format!("{dump_dir}/instance.be"),
        <F as ff::PrimeField>::to_repr(&instance).as_ref(),
    )
    .ok();
    eprintln!(
        "[poseidon_fixture] proof = {} bytes, vk_solidity = {} bytes, verifier_solidity = {} bytes; \
         dumps under {dump_dir}",
        proof.len(),
        vk_solidity.len(),
        verifier_solidity.len()
    );

    assert!(
        pinned_solc_available(),
        "{RUN_EVM_TESTS_ENV}=1 requires the pinned solc, which was not found or did not match.
\
         Install it, point SOLC at the binary, or set \
         HALO2_SOLIDITY_ALLOW_UNPINNED_SOLC=1 to accept another version."
    );

    let vk_creation_code = compile_solidity(&vk_solidity);
    let verifier_creation_code = compile_solidity(&verifier_solidity);

    // Deploy on Prague-spec revm (EIP-2537 routed via blst).
    let mut evm = Evm::default();
    let vk_address = evm.create(vk_creation_code);
    let verifier_address = evm.create_with_address_arg(verifier_creation_code, vk_address);

    // Re-pack the prover's 48-byte compressed G1 commitments into the
    // 128-byte EIP-2537 form expected by the generated Solidity.
    let repacked_len = generator.repack_proof(&proof).expect("proof repack should succeed").len();
    let calldata = generator
        .encode_calldata(&proof, &[instance])
        .expect("calldata encoding should succeed");
    std::fs::write(format!("{dump_dir}/calldata.bin"), &calldata).ok();
    eprintln!(
        "[poseidon_fixture] calldata = {} bytes (compressed_proof={}, repacked={}, instances={})",
        calldata.len(),
        proof.len(),
        repacked_len,
        1
    );

    use halo2_solidity_verifier::CallOutcome;
    match evm.try_call_with_gas(verifier_address, calldata, 5_000_000_000) {
        CallOutcome::Success {
            logs,
            gas_used,
            output,
        } => {
            if trace_solidity {
                dump_trace_logs(&logs);
            }
            if gas_checkpoints_enabled {
                dump_gas_checkpoints(&logs, gas_used);
            }
            let expected: Vec<u8> = [vec![0u8; 31], vec![1]].concat();
            assert_eq!(
                output,
                expected,
                "verifier should accept the proof; gas_used = {gas_used}, output = 0x{}",
                hex::encode(&output)
            );
            println!("Poseidon proof verified on-chain in {gas_used} gas");
        }
        CallOutcome::Revert { gas_used, output } => {
            panic!(
                "verifier reverted with gas_used = {gas_used}, output = 0x{}",
                hex::encode(&output)
            );
        }
        CallOutcome::Halt { gas_used, reason } => {
            panic!("verifier halted with gas_used = {gas_used}, reason = {reason}");
        }
    }
}

fn assert_poseidon_quotient_manifest(generator: &SolidityGenerator<'_>) {
    let manifest = generator.quotient_identity_manifest();
    let gate_names = manifest
        .entries
        .iter()
        .filter_map(|entry| match &entry.source {
            QuotientIdentitySource::Gate { gate_name, .. } => Some(gate_name.as_str()),
            _ => None,
        })
        .collect::<std::collections::BTreeSet<_>>();
    for expected in [
        "arith_gate",
        "12_minus_34",
        "parallel_add_gate",
        "full_round_gate",
    ] {
        assert!(
            gate_names.contains(expected),
            "Poseidon manifest should include normal gate {expected}; got {gate_names:?}"
        );
    }
    assert!(
        !gate_names.contains("partial_round_gate"),
        "partial_round_gate should be represented by trash, not normal gate identities"
    );
    let trash_names = manifest
        .entries
        .iter()
        .filter_map(|entry| match &entry.source {
            QuotientIdentitySource::Trash { trash_name, .. } => Some(trash_name.as_str()),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(manifest.trash_identities, 1);
    assert!(
        trash_names.iter().any(|name| name.contains("partial_round_gate")),
        "Poseidon trash manifest should name partial_round_gate; got {trash_names:?}"
    );
    assert_eq!(manifest.lookup_identities, 3);
    assert!(
        manifest.permutation_identities > 0,
        "Poseidon fixture should include copy/permutation identities"
    );
}

fn env_flag_enabled(name: &str) -> bool {
    env::var(name)
        .map(|value| {
            matches!(
                value.to_ascii_lowercase().as_str(),
                "1" | "true" | "yes" | "on"
            )
        })
        .unwrap_or(false)
}

fn dump_trace_logs(logs: &[halo2_solidity_verifier::revm::primitives::Log]) {
    for log in logs {
        let topic = log.data.topics()[0];
        let id = u64::from_be_bytes(topic.as_slice()[24..32].try_into().unwrap());
        let data = log.data.data.as_ref();
        if data.is_empty() {
            continue;
        }
        let name = match id {
            1 => "vk_digest",
            2 => "num_instances",
            3 => "k",
            4 => "n_inv",
            5 => "omega",
            6 => "omega_inv",
            7 => "theta",
            8 => "beta",
            9 => "gamma",
            10 => "y",
            11 => "x",
            12 => "trash_challenge",
            13 => "x1",
            14 => "x2",
            15 => "x3",
            16 => "x4",
            17 => "x_n",
            18 => "x_n_minus_1_inv",
            19 => "l_last",
            20 => "l_blind",
            21 => "l_0",
            22 => "instance_eval",
            23 => "linearization_expected_eval",
            24 => "quotient",
            25 => "f_com",
            26 => "pi",
            27 => "pairing_lhs",
            28 => "pairing_rhs",
            29 => "acc_lhs",
            30 => "acc_rhs",
            31 => "f_eval",
            32 => "v",
            33 => "final_com",
            34 => "linearization_commitment",
            35 => "final_result",
            36 => "quotient_numerator",
            1000..=1999 => "user_challenge",
            30000..=39999 => "quotient_identity_eval",
            40000..=40999 => "pcs_q_com",
            41000..=41999 => "pcs_point_set",
            60000..=60999 => "selector_fold",
            _ => "unknown",
        };
        if matches!(id, 24..=30 | 33..=34 | 40000..=40999) {
            eprintln!("[yul-trace] {name}");
            for (slot, word) in ["x_hi", "x_lo", "y_hi", "y_lo"].iter().zip(data.chunks_exact(32)) {
                eprintln!("[yul-trace]   {slot} = 0x{}", hex::encode(word));
            }
        } else if matches!(id, 41000..=41999) {
            eprintln!("[yul-trace] {name}[{id}]");
            for (idx, word) in data.chunks_exact(32).enumerate() {
                eprintln!("[yul-trace]   point[{idx}] = 0x{}", hex::encode(word));
            }
        } else {
            eprintln!("[yul-trace] {name}[{id}] = 0x{}", hex::encode(&data[0..32]));
        }
    }
}

/// Parse LOG1 events emitted by the rendered verifier when compiled
/// with `--features solidity-gas-checkpoints` and print a per-section
/// gas-delta breakdown.
///
/// Topic format: `(id << 248) | gas()`. `id` lives in the upper 8
/// bits and the remaining 248 bits hold `gas()`. We discard topics
/// where the upper byte is outside `1..=31` because the trace helpers
/// (`trace_u256` / `trace_point`) emit unrelated LOG1 events with
/// small `id` topics that may collide; here we filter to our own
/// checkpoint range. The poseidon fixture is built without the
/// `solidity-trace` feature in CI, so in practice the only LOG1
/// events are ours.
///
/// IDs 1..=16 are the top-level section boundaries (entry, VK,
/// transcript stages, quotient, linearization, PCS, accumulator,
/// pairing). IDs 17.. sit *inside* the PCS computation block (one
/// emitted between every pair of `pcs_computations` sub-blocks; the
/// last sub-block ends at cp14) and let us attribute the 514-kg PCS
/// bucket to each emitter sub-block. The exact mapping of id->block
/// depends on the circuit layout (one emitter block per (block 1,
/// block 2, *each* set in block 3, block 4, block 5, block 6) — for
/// the Poseidon fixture with 3 point sets that's 8 emitter blocks
/// and 7 mid-PCS checkpoints (cp17..=cp23) so this dumper allocates
/// space up to id=31 to leave headroom for larger circuits.
fn dump_gas_checkpoints(logs: &[halo2_solidity_verifier::revm::primitives::Log], gas_used: u64) {
    fn name_of(id: u8) -> &'static str {
        match id {
            1 => "entry (before VK loading)",
            2 => "VK loading + accumulator public-input precheck",
            3 => "VK digest + committed_pi + instance absorbs",
            4 => "user-phase advice reads + user challenge squeezes",
            5 => "theta squeeze + lookup multiplicities",
            6 => "beta/gamma + permutation Z products",
            7 => "lookup helpers + Z accumulators",
            8 => "trash_challenge + trashcans",
            9 => "y squeeze + quotient-limb reads",
            10 => "evaluations + x1/x2 + f_com + x3 + q_evals + x4 + pi",
            11 => "Lagrange + instance evaluation",
            12 => "batched identity numerator reconstruction",
            13 => "linearization scalar prep",
            14 => "PCS block 6 (pairing inputs LHS/RHS)",
            15 => "public accumulator pairing batch prep",
            16 => "final ec_pairing",
            // Poseidon-specific PCS sub-block layout (3 point sets):
            //   set 0: m=33 commits, 1 rotation
            //   set 1: m=5  commits, 2 rotations
            //   set 2: m=2  commits, 3 rotations
            17 => "PCS block 1 (rotation points x*omega^rot)",
            18 => "PCS block 2 (x1 powers)",
            19 => "PCS block 3 set 0 q_eval fold (m=33, 1 rot)",
            20 => "PCS block 3 set 1 q_eval fold (m=5, 2 rots)",
            21 => "PCS block 3 set 2 q_eval fold (m=2, 3 rots)",
            22 => "PCS block 4 (f_eval Lagrange interpolation)",
            23 => "PCS block 5 (final_com x4-power MSM + v)",
            _ => "<unknown>",
        }
    }

    let mut events: Vec<(u8, u64)> = logs
        .iter()
        .filter_map(|log| {
            let topic = log.data.topics().first()?;
            let bytes = topic.as_slice();
            // Upper byte = checkpoint id; lower 31 bytes = gas() (only
            // the lowest 8 are non-zero in practice for gas values
            // < 2^64). We read the lowest 8 bytes as u64.
            let id = bytes[0];
            if !(1..=31).contains(&id) {
                return None;
            }
            let gas = u64::from_be_bytes(bytes[24..32].try_into().ok()?);
            Some((id, gas))
        })
        .collect();
    // Sort by execution order: gas_left is monotonically decreasing,
    // so descending-gas == earliest-emitted-first. This is more
    // robust than sort-by-id because the PCS sub-block ids
    // (17..=21) are emitted *between* cp13 and cp14.
    events.sort_by(|a, b| b.1.cmp(&a.1));

    if events.is_empty() {
        eprintln!(
            "[gas-checkpoints] no checkpoint events found in {} LOG entries",
            logs.len()
        );
        return;
    }

    eprintln!();
    eprintln!("=== gas-checkpoint breakdown (per-section deltas) ===");
    eprintln!(
        "{:>4}  {:>14}  {:>12}  {:>7}  section",
        "id", "gas_left", "delta", "%"
    );

    // Each checkpoint costs ~750 gas (LOG1 base 375 + 1 topic 375 +
    // 0 data bytes). Subtract that from each delta so the printed
    // numbers reflect "real" section work, not measurement overhead.
    const CHECKPOINT_COST: u64 = 750;

    let total_billed = if events[events.len() - 1].1 < events[0].1 {
        events[0].1.saturating_sub(events[events.len() - 1].1)
    } else {
        0
    };
    let total_real_work = total_billed.saturating_sub(events.len() as u64 * CHECKPOINT_COST);

    let mut prev_gas = events[0].1;
    let cp1_gas = events[0].1;
    eprintln!(
        "{:>4}  {:>14}  {:>12}  {:>7}  {}",
        events[0].0,
        format_u64(prev_gas),
        "-",
        "-",
        name_of(events[0].0),
    );

    for (id, gas) in events.iter().skip(1) {
        let raw_delta = prev_gas.saturating_sub(*gas);
        let net_delta = raw_delta.saturating_sub(CHECKPOINT_COST);
        let pct = if total_real_work > 0 {
            (net_delta as f64 / total_real_work as f64) * 100.0
        } else {
            0.0
        };
        eprintln!(
            "{:>4}  {:>14}  {:>12}  {:>6.1}%  {}",
            id,
            format_u64(*gas),
            format_u64(net_delta),
            pct,
            name_of(*id),
        );
        prev_gas = *gas;
    }

    eprintln!();
    eprintln!(
        "  cp1 gas_left            = {} (verifier entry)",
        format_u64(cp1_gas)
    );
    eprintln!(
        "  cp16..cp1 gas billed    = {} (work between cp1 and cp16)",
        format_u64(total_billed)
    );
    eprintln!(
        "  - measurement overhead  = {} ({} checkpoints x {} gas)",
        format_u64(events.len() as u64 * CHECKPOINT_COST),
        events.len(),
        CHECKPOINT_COST
    );
    eprintln!(
        "  = real section work     = {}",
        format_u64(total_real_work)
    );
    eprintln!(
        "  total tx gas_used       = {} (incl. tx base + calldata + pre-cp1 + post-cp16)",
        format_u64(gas_used)
    );
}

fn format_u64(n: u64) -> String {
    let s = n.to_string();
    let bytes = s.as_bytes();
    let mut out = String::with_capacity(s.len() + s.len() / 3);
    for (i, b) in bytes.iter().enumerate() {
        if i > 0 && (bytes.len() - i).is_multiple_of(3) {
            out.push(',');
        }
        out.push(*b as char);
    }
    out
}

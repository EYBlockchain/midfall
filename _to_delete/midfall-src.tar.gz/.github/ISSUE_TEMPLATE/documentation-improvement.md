---
name: Documentation improvement
about: Report a problem with the documentation
title: ""
labels: midnight-zk, public, documentation
assignees: ""
---

Documentation Improvement: Clearly describe the improvement requested for existing content and/or raise missing areas of documentation and provide details for what should be included.

### Documentation URL:
<!-- Specify the exact location of the documentation you are referencing. -->

### Description of Improvement:
<!-- Provide a detailed description of the requested improvement. -->

### Proposed Solution (Optional):
<!-- If you have specific suggestions for how to implement the improvement, provide them here.
This could include suggested wording, code snippets, or structural changes -->

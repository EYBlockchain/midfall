// This file is part of MIDNIGHT-ZK.
// Copyright (C) Midnight Foundation
// SPDX-License-Identifier: Apache-2.0
// Licensed under the Apache License, Version 2.0 (the "License");
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Integration tests for identifying breaking changes in circuits

use midnight_zk_stdlib::{
    utils::plonk_api::{check_vk, srs_for_test, update_circuit_goldenfiles},
    MidnightCircuit,
};

#[path = "../examples/exposing_types.rs"]
mod exposing_types;

use exposing_types::{
    bitcoin_ecdsa_threshold::BitcoinThresholdECDSA,
    bitcoin_signature::BitcoinSigExample,
    ecc_ops::EccExample,
    ethereum_signature::EthereumSigExample,
    hybrid_mt::HybridMtExample,
    identity::{
        enrollment::CredentialEnrollment, full_credential::FullCredential,
        property_check::CredentialProperty,
    },
    membership::MembershipExample,
    native_gadget::NativeGadgetExample,
    poseidon::PoseidonExample,
    rsa_signature::RSASignatureCircuit,
    schnorr_sig::SchnorrExample,
    sha_preimage::ShaPreImageCircuit,
};

macro_rules! generate_tests {
    ($($name:ident: $circuit:ty),*) => {
        $(
            #[test]
            fn $name() {
                let relation = <$circuit>::default();

                update_circuit_goldenfiles(&relation);

                let srs = srs_for_test(&relation, None);
                let vk = midnight_zk_stdlib::setup_vk(&srs, &relation);
                check_vk::<MidnightCircuit<$circuit>>(&vk);
            }
        )*
    };
}

generate_tests!(
    check_vk_ecc: EccExample,
    check_vk_bitcoin: BitcoinThresholdECDSA,
    check_vk_ethereum_sig: EthereumSigExample,
    check_vk_bitcoin_sig: BitcoinSigExample,
    check_vk_rsa: RSASignatureCircuit,
    check_vk_poseidon: PoseidonExample,
    check_vk_native: NativeGadgetExample,
    check_vk_membership: MembershipExample,
    check_vk_cred_full: FullCredential,
    check_vk_cred_enrollment: CredentialEnrollment,
    check_vk_cred_property: CredentialProperty,
    check_vk_hybrid_mt: HybridMtExample,
    check_vk_sha: ShaPreImageCircuit,
    check_vk_schnorr: SchnorrExample
);

// This file is part of MIDNIGHT-ZK.
// Copyright (C) Midnight Foundation
// SPDX-License-Identifier: Apache-2.0
// Licensed under the Apache License, Version 2.0 (the "License");
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! This module provides a set of tools for in/off-circuit hashing into elliptic
//! curves.
//!
//! See RFC 9380 <https://www.rfc-editor.org/rfc/rfc9380.html>.
//!
//! We adapt the above techniques to also hash into Edwards curves.

mod htc_gadget;
mod mtc;
mod mtc_cpu;
mod mtc_params;

pub use htc_gadget::*;
pub use mtc::MapToCurveInstructions;
pub use mtc_cpu::MapToCurveCPU;
pub use mtc_params::MapToEdwardsParams;
